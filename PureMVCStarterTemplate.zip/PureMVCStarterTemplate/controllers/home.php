<?php 

class Home extends Controller 
{
    public function __construct() 
    {
        parent::__construct();
    }

    public function index($args) 
    {
        echo 'Welcome!';
    }
}
