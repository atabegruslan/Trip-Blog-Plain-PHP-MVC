<?php

class Bootstrap 
{
    public function __construct() 
    {
        self::setup_routes();
    }

    private function setup_routes()
    {
        $url = isset($_GET['url']) ? $_GET['url'] : null; // Case: http://url.domain/

        $url = rtrim($url, '/'); // Case: http://url.domain/controller///////
        $url = explode('/', $url);

        $controllerName = empty($url[0]) ? 'home'  : $url[0];
        $action         = empty($url[1]) ? 'index' : $url[1];
        $parameters     = empty($url[2]) ? array() : array_slice($url, 2);

        if (!file_exists('controllers/' . $controllerName . '.php')) 
        {
            return false;			
        }

        $controller = new $controllerName;

        if (!method_exists($controller, $action)) 
        {
            return false;
        }

        $controller->{$action}($parameters);
    }
}
